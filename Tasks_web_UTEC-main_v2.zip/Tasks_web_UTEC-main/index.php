<?php
session_start();
require 'helpers/conexion.php';

// Verificar si el usuario ha iniciado sesión[cite: 16]
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

$id_usuario = $_SESSION['usuario_id'];

// --- PROCESAR ACCIONES (ACTUALIZAR Y ELIMINAR) ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['accion'])) {
    $id_tarea = $_POST['id_tarea'];

    if ($_POST['accion'] == 'toggle') {
        // Cambiar estado de completada (0 a 1, o 1 a 0)
        $estado_actual = $_POST['estado_actual'] == 1 ? 0 : 1;
        $sql_update = "UPDATE tareas SET completada = :estado WHERE id_tarea = :id_tarea AND id_usuario = :id_usuario";
        $stmt_update = $conexion->prepare($sql_update);
        $stmt_update->execute([
            ':estado' => $estado_actual,
            ':id_tarea' => $id_tarea,
            ':id_usuario' => $id_usuario
        ]);
    } 
    elseif ($_POST['accion'] == 'eliminar') {
        // Eliminar tarea
        $sql_delete = "DELETE FROM tareas WHERE id_tarea = :id_tarea AND id_usuario = :id_usuario";
        $stmt_delete = $conexion->prepare($sql_delete);
        $stmt_delete->execute([
            ':id_tarea' => $id_tarea,
            ':id_usuario' => $id_usuario
        ]);
    }
    
    // Recargar la página para evitar reenvío de formularios
    header("Location: index.php");
    exit();
}

// --- OBTENER ESTADÍSTICAS ---
$stats = ['totales' => 0, 'completadas' => 0, 'pendientes' => 0];
try {
    $stmt_stats = $conexion->prepare("SELECT 
        COUNT(*) as totales, 
        SUM(CASE WHEN completada = 1 THEN 1 ELSE 0 END) as completadas,
        SUM(CASE WHEN completada = 0 THEN 1 ELSE 0 END) as pendientes
        FROM tareas WHERE id_usuario = :id");
    $stmt_stats->execute([':id' => $id_usuario]);
    $resultado = $stmt_stats->fetch();
    if ($resultado) {
        $stats['totales'] = $resultado['totales'] ?? 0;
        $stats['completadas'] = $resultado['completadas'] ?? 0;
        $stats['pendientes'] = $resultado['pendientes'] ?? 0;
    }
} catch (PDOException $e) { }

// --- OBTENER TAREAS ---
$tareas = [];
try {
    // Unimos la tabla tareas con materias para obtener el nombre de la materia
    $sql_tareas = "SELECT t.id_tarea, t.titulo, t.completada, m.nombre AS materia 
                   FROM tareas t 
                   LEFT JOIN materias m ON t.id_materia = m.id_materia 
                   WHERE t.id_usuario = :id_usuario 
                   ORDER BY t.completada ASC, t.fecha_asignada ASC";
    $stmt_tareas = $conexion->prepare($sql_tareas);
    $stmt_tareas->execute([':id_usuario' => $id_usuario]);
    $tareas = $stmt_tareas->fetchAll();
} catch (PDOException $e) { }

// Configurar saludo según la hora
$hora = date('H');
$saludo = ($hora < 12) ? 'Buenos días' : (($hora < 19) ? 'Buenas tardes' : 'Buenas noches');
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - TaskManager</title>
    <link rel="stylesheet" href="css/formularioTarea.css">
    <link rel="icon" href="favicon.svg" type="image/svg+xml">
</head>
<body>

    <!-- Menú lateral[cite: 16] -->
    <?php include 'includes/sidebar.php'; ?>

    <!-- Contenido Principal -->
    <div class="main-content">
        
        <div class="dashboard-header">
            <div class="header-text">
                <h1 style="color: #3b82f6; font-size: 1.8rem; margin-bottom: 5px;"><?php echo $saludo; ?>, <?php echo htmlspecialchars(explode(' ', trim($_SESSION['usuario_nombre']))[0]); ?></h1>
                <p style="color: #6b7280; font-size: 0.95rem;">Resumen de tus tareas de hoy</p>
            </div>
            <div>
                <input type="text" class="search-bar" placeholder="Buscar tarea...">
            </div>
        </div>

        <!-- Tarjetas de Estadísticas[cite: 17] -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3><?php echo $stats['totales']; ?></h3>
                <p>Tareas totales</p>
            </div>
            <div class="stat-card green">
                <h3><?php echo $stats['completadas']; ?></h3>
                <p>Completadas</p>
            </div>
            <div class="stat-card blue">
                <h3><?php echo $stats['pendientes']; ?></h3>
                <p>Por completar</p>
            </div>
        </div>

        <!-- Cuadrícula Principal[cite: 17] -->
        <div class="main-grid">
            
            <!-- Columna Izquierda: Lista de Tareas -->
            <div class="panel">
                <h2 class="panel-title">Tus tareas</h2>
                
                <?php if (count($tareas) > 0): ?>
                    <?php foreach($tareas as $tarea): ?>
                        <div class="task-item">
                            <div class="task-left">
                                <!-- Formulario invisible para actualizar estado -->
                                <form action="index.php" method="POST" class="form-toggle">
                                    <input type="hidden" name="accion" value="toggle">
                                    <input type="hidden" name="id_tarea" value="<?php echo $tarea['id_tarea']; ?>">
                                    <input type="hidden" name="estado_actual" value="<?php echo $tarea['completada']; ?>">
                                    <input type="checkbox" class="task-checkbox" onchange="this.form.submit()" <?php echo $tarea['completada'] ? 'checked' : ''; ?>>
                                </form>
                                <span class="task-title <?php echo $tarea['completada'] ? 'completed' : ''; ?>">
                                    <?php echo htmlspecialchars($tarea['titulo']); ?>
                                </span>
                            </div>
                            <div class="task-right">
                                <!-- Etiqueta de la materia -->
                                <?php if($tarea['materia']): ?>
                                    <span class="badge"><?php echo htmlspecialchars($tarea['materia']); ?></span>
                                <?php endif; ?>
                                
                                <!-- Formulario para eliminar -->
                                <form action="index.php" method="POST" onsubmit="return confirm('¿Eliminar esta tarea?');" style="margin: 0;">
                                    <input type="hidden" name="accion" value="eliminar">
                                    <input type="hidden" name="id_tarea" value="<?php echo $tarea['id_tarea']; ?>">
                                    <button type="submit" class="btn-delete-icon" title="Eliminar">&times;</button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p style="color: #6b7280; text-align: center; padding: 20px;">No tienes tareas pendientes.</p>
                <?php endif; ?>
            </div>

            <!-- Columna Derecha -->
            <div class="right-column" style="display: flex; flex-direction: column; gap: 20px;">
                
                <!-- Panel de Progreso Semanal (Estructura base del boceto)[cite: 17] -->
                <div class="panel">
                    <h2 class="panel-title">Progreso semanal</h2>
                    <div style="height: 150px; display: flex; align-items: flex-end; justify-content: space-around; gap: 10px; padding-bottom: 20px; border-bottom: 2px solid #f3f4f6;">
                        <!-- Simulación de barras[cite: 17] -->
                        <div style="width: 30px; height: 30%; background-color: #3b82f6; border-radius: 6px;"></div>
                        <div style="width: 30px; height: 70%; background-color: #3b82f6; border-radius: 6px;"></div>
                        <div style="width: 30px; height: 40%; background-color: #3b82f6; border-radius: 6px;"></div>
                        <div style="width: 30px; height: 90%; background-color: #3b82f6; border-radius: 6px;"></div>
                        <div style="width: 30px; height: 50%; background-color: #3b82f6; border-radius: 6px;"></div>
                    </div>
                    <div style="display: flex; justify-content: space-around; margin-top: 10px; font-weight: bold; color: #4b5563;">
                        <span>L</span><span>M</span><span>M</span><span>J</span><span>V</span>
                    </div>
                </div>

            </div>
        </div>
        <br>
        <br>
        <!-- Carrusel del Proyecto -->
        <div class="carousel-container">
            <div class="carousel-track" id="carouselTrack">
                <!-- Imagen 1 -->
                <div class="carousel-slide">
                    <img src="img/proyecto1.jpg" alt="Proyecto 1">
                </div>
                <!-- Imagen 2 -->
                <div class="carousel-slide">
                    <img src="img/proyecto2.jpg" alt="Proyecto 2">
                </div>
                <!-- Imagen 3 -->
                <div class="carousel-slide">
                    <img src="img/proyecto3.jpg" alt="Proyecto 3">
                </div>
            </div>
            
            <!-- Botones de navegación -->
            <button class="carousel-btn prev" onclick="moveSlide(-1)">&#10094;</button>
            <button class="carousel-btn next" onclick="moveSlide(1)">&#10095;</button>

            <!-- Indicadores -->
            <div class="carousel-indicators">
                <span class="dot active" onclick="currentSlide(0)"></span>
                <span class="dot" onclick="currentSlide(1)"></span>
                <span class="dot" onclick="currentSlide(2)"></span>
            </div>
        </div>
        <?php include 'includes/footer.php'; ?>
    </div>
    <script>
        let currentIndex = 0;
        const totalSlides = 3;

        function moveSlide(step) {
            currentIndex += step;
            if (currentIndex >= totalSlides) currentIndex = 0;
            if (currentIndex < 0) currentIndex = totalSlides - 1;
            updateCarousel();
        }

        function currentSlide(index) {
            currentIndex = index;
            updateCarousel();
        }

        function updateCarousel() {
            const track = document.getElementById('carouselTrack');
            const dots = document.querySelectorAll('.dot');
            
            // Mover el contenedor multiplicando el índice por el porcentaje de ancho
            track.style.transform = `translateX(-${currentIndex * 33.3333}%)`;
            
            // Actualizar el estilo de los puntos indicadores
            dots.forEach(dot => dot.classList.remove('active'));
            dots[currentIndex].classList.add('active');
        }

        // Desplazamiento automático cada 5 segundos
        setInterval(() => {
            moveSlide(1);
        }, 5000);
    </script>
</body>
</html>