<footer class="footer-sitio">
    <div class="contenedor contenedor-footer">
        <!-- Derechos reservados -->
        <p>&copy; 2026 TaskManager Académico. Todos los derechos reservados.</p>
        
        <!-- Enlaces -->
        <ul class="links-footer">
            <!-- Cambié index.html a index.php porque ahora tu inicio es PHP -->
            <li><a href="index.php">Inicio</a></li> 
            <li><a href="servicios.html">Servicios</a></li>
            <li><a href="nosotros.html">Nosotros</a></li>
            <li><a href="contacto.html">Contacto</a></li>
        </ul>
        
        <!-- Contenedor del reloj dinámico -->
        <div id="fecha-hora" class="fecha-hora-footer"></div>
    </div>
</footer>

<script>
    // Función para actualizar la fecha y hora en tiempo real
    function actualizarReloj() {
        const ahora = new Date();
        
        // Formatear la fecha (ej: 25 de octubre de 2026)
        const opcionesFecha = { year: 'numeric', month: 'long', day: 'numeric' };
        const fecha = ahora.toLocaleDateString('es-ES', opcionesFecha);
        
        // Formatear la hora (ej: 18:53:10)
        const hora = ahora.toLocaleTimeString('es-ES');
        
        // Insertar en el div
        document.getElementById('fecha-hora').textContent = `${fecha} - ${hora}`;
    }

    // Ejecutar la función cada 1000 milisegundos (1 segundo)
    setInterval(actualizarReloj, 1000);
    
    // Llamar la función inmediatamente para que no haya un segundo de retraso al cargar
    actualizarReloj();
</script>