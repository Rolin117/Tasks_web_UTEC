<?php
$pagina_actual = basename($_SERVER['PHP_SELF']);
?>
<!-- Menú lateral -->
<div class="sidebar">
    <div>
        <a href="index.html" style="text-decoration: none; color: white;">
            <h2>TaskManager</h2>
        </a>
        <a href="index.php" class="nav-item <?php echo ($pagina_actual == 'index.php') ? 'active' : ''; ?>">Inicio</a>
        <a href="formulario_tarea.php" class="nav-item <?php echo ($pagina_actual == 'formulario_tarea.php') ? 'active' : ''; ?>">Tareas</a>
        <a href="#" class="nav-item">Calendario</a>
        <a href="materias.php" class="nav-item <?php echo ($pagina_actual == 'materias.php') ? 'active' : ''; ?>">Materias</a>
    </div>

    <!-- Enlace al archivo logout.php que ya tienes creado -->
    <a href="logout.php" class="nav-item logout-btn">Cerrar sesión</a>
</div>